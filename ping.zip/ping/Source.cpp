#include <iostream>
#include <fstream> // for ofstream
#include <conio.h> // for getch()

using namespace std;

int main()
{
	char site[512];
	cout << "Site : "; // enter the site
	cin.getline(site,512);  // get you site

	ofstream mhb;
	mhb.open("d:\mb.bat"); // create and open the file
	mhb << "@echo off\n"; //from line 15 to 19 writing commands to yr file
	mhb << "cd / \n";
	mhb << "ping ";
	mhb << site;
	mhb << " -t";
	mhb.close(); // close the fu**ing file

	system("d:\mb.bat"); // open the goddmn file


	/*
		char result; // setting up this stupid for ctrl+c to stop 
	result = getch(); 
	switch(result)
	{
	case 3: break;
	}

	forget it ... 
	*/
	
	
	return 0;
}